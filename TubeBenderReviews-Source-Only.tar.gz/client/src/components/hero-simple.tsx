export default function HeroSimple() {
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-blue-950/20 via-blue-900/30 to-indigo-900/20">
      {/* Simple gradient overlay - no animation */}
    </div>
  );
}