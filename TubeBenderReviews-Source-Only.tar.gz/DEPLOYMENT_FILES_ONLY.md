# TubeBenderReviews - Deployment Package

## What's Included
✅ All source code (client/, server/, shared/)
✅ Configuration files (vercel.json, .nvmrc, package.json, etc.)
✅ Deployment guide (VERCEL_DEPLOYMENT_GUIDE.md)
✅ Build configurations (vite.config.ts, tailwind.config.ts)
✅ Database schema (shared/schema.ts)

## What's Excluded (Not Needed for Deployment)
❌ node_modules (Vercel installs fresh)
❌ attached_assets (large development images - 17MB+)
❌ .git (create fresh repository)
❌ dist folder (Vercel builds fresh)
❌ Development cache and logs

## Production Images
The application uses placeholder images for production. Real product images should be:
1. Uploaded to a CDN (Cloudinary, Vercel Blob, etc.)
2. Or stored in a proper asset management system
3. Referenced via URLs in the database

## File Size
- This archive: ~2-5MB (manageable for Replit download)
- Previous archive: 337MB (failed due to attached images)

## Next Steps
1. Download this minimal archive
2. Upload to GitHub
3. Deploy to Vercel using the guide
4. Add production images separately through admin panel or CDN